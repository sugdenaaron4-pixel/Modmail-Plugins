
# Jet2Support Modmail Plugin

Features:
- Department navigation system
- Queue tracking by department
- Live queue updates
- Claim notifications
- Modmail permission compatibility
- Modmail v4 + dev support

## Installation

1. Upload the plugin folder
2. Install requirements:
```bash
pip install -r requirements.txt
```

3. Load plugin:
```bash
plugins add jet2support_plugin
plugins load jet2support_plugin
```

## Departments

01 General Inquiries  
02 Billing & Finance  
03 Public Relations  
04 Legal & Abuse  
05 Senior Management  
06 Other / Unsure

## Queue System

- Queue is separated by department
- Claimed tickets stop queue updates
- Queue updates are sent in user DMs
